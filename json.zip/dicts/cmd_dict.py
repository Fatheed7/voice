cmd_dict = {
    'random': 'npc_random.npc_random_cmd(self, client)',
    'skyrim': 'skyrim.skyrim_cmd(self, client)',
    'last': 'last.last_cmd("read", None, self)',
    '!npc': 'embed.embed_cmd(self.channel)',
    '!temp': 'temperature.temperature_cmd(self)'
}
