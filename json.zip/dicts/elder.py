elderscrolls_dict = {
    'arrow': 'skyrim/maleguard/dialogueguardsgeneral__00020954_1.wav',
    'bed': 'oblivion/Imperial/f/nqdanvil_greeting_0003e094_1.mp3',
    'cheese': 'oblivion/sheogorath/m/se04shell_'
             'se04xedilianchoice_00044f52_1.mp3',
    'curved': 'skyrim/maleguard/dialogueguardsgeneral__000dd0db_1.wav',
    'fight': 'oblivion/high elf/m/generic_assaultnocrime_00062503_1.mp3',
    'knowyou': 'oblivion/breton/m/MS10_HELLO_0003C33F_1.mp3',
    'lemons': 'skyrim/clown.mp3',
    'necro': 'oblivion/high elf/f/NQDSkingrad_SkingradTopic_00038AA1_3.mp3',
    'ni': 'oblivion/argonian/f/senqdmania_serunsincirclesyell_00041211_1.mp3',
    'nick': 'deerpenis.mp3',
    'pp': 'oblivion/Imperial/m/generic_pickpocket_00062274_1.mp3',
    'snort': 'oblivion/Imperial/m/generic_transition_0002a85b_1.mp3'
}
